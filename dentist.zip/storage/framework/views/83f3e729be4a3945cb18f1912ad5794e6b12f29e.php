<?php echo $__env->make('layout.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

    </div>
    <div class="container col-md-10">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php if(Auth::user()->name != 'admin'): ?>
                    <?php if($param == 'e'): ?>
                        <?php if($numberOfSched == 1): ?>
                            <h5 class="alert alert-primary">Imate jos <?php echo e($numberOfSched); ?> termin na cekanju</h5>
                        <?php else: ?>
                            <h5 class="alert alert-primary">Imate jos <?php echo e($numberOfSched); ?> termina na cekanju</h5>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if($numberOfSched == 1): ?>
                            <h5 class="alert alert-primary">Imate <?php echo e($numberOfSched); ?> termin zakazan </h5>
                        <?php else: ?>
                            <h5 class="alert alert-primary">Imate <?php echo e($numberOfSched); ?> termina zakazana </h5>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <?php if(Auth::user()->name === 'admin'): ?>
                            <h3><?php echo e(__('Termini svih pacijenata')); ?></h3>
                        <?php else: ?>
                            <?php if(count($sched) == 0): ?>
                                <h3><?php echo e(__('Vasi termini su na cekanju')); ?></h3>
                            <?php else: ?>
                                <h3><?php echo e(__('Potvrdjeni termini')); ?></h3>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(count($sched) > 0): ?>
                            <?php if(Auth::user()->name != 'admin'): ?>
                                <?php echo Form::open(['action' => ['App\Http\Controllers\HomeController@index'], 'method' => 'GET', 'enctype' => 'multipart/form-data', 'class' => 'search-form']); ?>

                                <div id="dropdown-list" class="float-right "> <?php echo Form::select('unschedule', ['e' => 'zakazani termini', 's' => 'nezakazani termini'], ['class' => 'dropdown-list']); ?>

                                </div>
                                <?php echo Form::submit('Search', ['class' => 'btn btn-primary float-right']); ?>

                                <?php echo Form::close(); ?>

                            <?php endif; ?>
                            <table class="table-responsive table-dashboard">
                                <tr>
                                    <th>Ime pacijenta</th>
                                    <th>Naslov</th>
                                    <th>Poruka</th>
                                    <th>Pocetni datum</th>
                                    <th>Krajnji datum</th>
                                </tr>
                                <?php $__currentLoopData = $sched; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td scope="col"><?php echo e($s->name); ?></td>
                                        <td scope="col"><?php echo e($s->title); ?></td>
                                        <td scope="col"><?php echo e($s->description); ?></td>
                                        <?php if($s->start == ''): ?>
                                            <td scope="col"><a href="full-calender?id=<?php echo e($s->id); ?>"
                                                    class="btn btn-primary col-md-6">Dodaj termin</a></td>
                                        <?php else: ?>
                                            <td scope="col"><?php echo e($s->start); ?></td>
                                            <td scope="col"><?php echo e($s->end); ?></td>
                                        <?php endif; ?>
                                        <td scope="col"> <a class="btn btn-info col-md-12 float-right"
                                                href="dashboard/show/<?php echo e($s->id); ?>">Informacije</a></td>
                                        <?php if(Auth::user()->name === 'admin'): ?>
                                            <?php echo Form::open(['action' => ['App\Http\Controllers\HomeController@destroy', $s->id], 'method' => 'POST', 'enctype' => 'multipart/form-data', 'class' => 'submit-form']); ?>

                                            <td scope="col"> <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                                <?php echo e(Form::submit('Obrisi', ['class' => 'col-md-12 float-right btn btn-danger'])); ?>

                                            </td>
                                            <?php echo Form::close(); ?>

                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        <?php else: ?>
                            <?php if(count($sched) > 0): ?>
                                <table class="table-dashboard">
                                    <tr>
                                        <th>Naslov</th>
                                        <th>Poruka</th>
                                        <th>Pocetni zeljeni termin</th>
                                        <th>Krajnji zeljeni termin</th>
                                    </tr>
                                    <?php $__currentLoopData = $sched; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td scope="col"><?php echo e($s->subject); ?></td>
                                            <td scope="col"><?php echo e($s->message); ?></td>
                                            <td scope="col"><?php echo e($s->scheduleDate); ?></td>
                                            <td scope="col"><?php echo e($s->scheduleEndDate); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            <?php else: ?>
                                <h1>Nemate zakazanih usluga</h1>
                            <?php endif; ?>
                        <?php endif; ?>


                        <a class="btn btn-primary float-right" href="schedule/create" id="termin">Zakazi novi termin</a>

                        <div id="pagination" class="d-flex justify-content-center" style="margin-top:30px; font-size:22px;">
                            <?php echo e($sched->links()); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cvetko/dentists/resources/views/dashboard.blade.php ENDPATH**/ ?>