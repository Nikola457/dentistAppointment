<?php echo $__env->make('layout/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">               
         <a href="<?php echo e(URL('patients')); ?>" class="btn btn-dark">Go Back</a><br><br>
        <?php if(count($user) > 0): ?>
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3>Istorija pacijenta: <?php echo e($u->name); ?> 
        </h3>
        <?php echo Form::open(['action' => ['App\Http\Controllers\HomeController@show',$u->id], 'method' => 'GET', 'enctype' => 'multipart/form-data',  'class' => 'search-form']); ?>    
       <div id="dropdown-list" class="float-right "> <?php echo Form::select('filterBy', array('desc' => 'date desc', 'asc' => 'date asc'),['class' => 'dropdown-list']); ?>

           </div>
        <?php echo Form::submit("Search",['class' => 'btn btn-primary float-right']); ?>

        <?php echo Form::close(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(count($schedules) > 0 ): ?>
            <table class="patients-table">
                <tr><th>Ime usluge</th>
                    <th>Datum obavljanja usluge: </th>
                    <th>Vise informacija: </th>
                    </tr>
                <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($schedule->title); ?></td>
                    <td><?php echo e($schedule->start); ?> - <?php echo e($schedule->end); ?></td>
                    <td><a class="btn btn-info" href="<?php echo e(url('dashboard/show/'.$schedule->id)); ?>">Vise Informacija</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php else: ?><br> 
            <h4>Pacijent nema istoriju lecenja</h4>
            <?php endif; ?>
            <div id="pagination" class="d-flex justify-content-center" style="margin-top:30px; font-size:22px;"><?php echo e($schedules->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cvetko/dentists/resources/views/dashboard/history.blade.php ENDPATH**/ ?>