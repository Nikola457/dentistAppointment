<?php echo $__env->make('layout.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container col-md-12">
    <div class="row justify-content-center">
        <div class="col-md-8">              
            <div class="card">
                <div class="card-header">
                    <?php if(Auth::user()->name === 'admin'): ?>
                    <h3><?php echo e(__('Termini na cekanju ')); ?></h3></div>
                    <?php else: ?>
                    <h3><?php echo e(__('Vase zakazivanje')); ?></h3></div>
                    <?php endif; ?>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(count($schedules)>0): ?>
                    <table class="table-responsive table-dashboard">
                        <tr><th>Pacijent </th><th>Naslov </th><th>Opis </th><th>Pocetak Termina</th><th>Kraj Termina</th></tr>
                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($schedule->scheduleDate != ""): ?>
                        <tr>
                            <td><?php echo e($schedule->name); ?></td>
                            <td><?php echo e($schedule->subject); ?></td>
                            <td><?php echo e($schedule->message); ?></td>
                            <td><?php echo e($schedule->scheduleDate); ?></a></td>
                            <td><?php echo e($schedule->scheduleEndDate); ?></a></td>
                            <td><a href="full-calender?id=<?php echo e($schedule->scheduleId); ?>" class="btn btn-primary col-md-12">Zakazi</a></td>
                            <td> <a class="btn btn-info col-md-12 float-right" href="unscheduled/show/<?php echo e($schedule->scheduleId); ?>">Informacije</a></td>
                            <?php if(Auth::user()->name === 'admin'): ?>
                            <?php echo Form::open(['action' => ['App\Http\Controllers\ScheduleController@destroy', $schedule->scheduleId], 'method' => 'POST', 'enctype' => 'multipart/form-data',  'class' => 'submit-form']); ?>    
                            <td scope="col"> <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                   <?php echo e(Form::submit('Obrisi',["class" => "col-md-12 float-right btn btn-danger"])); ?></td>
                                        <?php echo Form::close(); ?>

                            <?php endif; ?>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </table>
                <a class="btn btn-primary float-right" href="schedule/create">Zakazi novi termin</a>
                <?php else: ?> 
                <h1>Nemate zakazanih usluga</h1>
                <a class="btn btn-primary" href="schedule/create">Zakazi novi termin</a>
                <?php endif; ?>
                </div>   
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cvetko/dentists/resources/views/unscheduled.blade.php ENDPATH**/ ?>