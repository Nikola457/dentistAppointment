
<?php echo $__env->make('layout/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<body>

    <!--====== HEADER PART START ======-->
   
            <div class="success-msg"><?php echo $__env->make('layout/success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
     

        <div id="home" class="header-hero bg_cover" style="background-image: url(https://www.marcusdblackdds.com/wp-content/uploads/2020/04/difference-between-endodontist-vs-dentist.jpg)">
            <div class="container"> 
                <?php echo $__env->make('layouts.indexNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row justify-content-center">
                    <div class="col-xl-8 col-lg-10">
                        <div class="header-content text-center">
                            <h1 class="header-title"><b>One Password to Rule Them All</b><br>World's Most Popular Password Manager</h1>
                            <p class="text">A simple and easy way to stay secure online.<br>Remember only one password while<br>never using the same password again!</p>
                            <ul class="header-btn">
                                <li><a class="main-btn btn-one" href="#">SIGN UP FOR FREE</a></li>
                                <li><a class="main-btn btn-two" href="#">Learn about premium</a></li>
                            </ul>
                        </div> <!-- header content -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
            <div class="header-shape">
                <img src="images/header-shape.svg" alt="shape">
            </div>
       
    <!--====== HEADER PART ENDS ======-->

	<div class="publications-image">
		<img src="images/lp-trust-media-desktop.svg">
			</div>
		
    <!--====== SERVICES PART START ======-->

    <section id="service" class="services-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section-title pb-10">
                        <h4 class="title">Do any of these two apply to you:</h4>
                        <p class="text"><ul><li><b>•	Using the same password for two or more websites/apps<br><li>•	Constantly forgetting your passwords and having to reset them all the time</b></ul></p>
                        	<p class="text"> If so, then LastPass is the right choice for you. <br>LastPass is one of the most popular password managers with end-to-end encryption. That means that even if LastPass becomes compromised your passwords will still remain secured and inaccessible to the attackers.</p>
                    </div> <!-- section title -->
                </div>
            </div> <!-- row -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="services-content mt-40 d-sm-flex">
                                <div class="services-icon">
                                    <i class="lni-bolt"></i>
                                </div>
                                <div class="services-content media-body">
                                    <h4 class="services-title">Log in Faster</h4>
                                    <p class="text">Auto fills your credentials</br> for one click sign in.</p>
                                </div>
                            </div> <!-- services content -->
                        </div>
                        <div class="col-md-6">
                            <div class="services-content mt-40 d-sm-flex">
                                <div class="services-icon">
                                    <i class="lni-bar-chart"></i>
                                </div>
                                <div class="services-content media-body">
                                    <h4 class="services-title">Generate secure passwords</h4>
                                    <p class="text">When signing up, auto-generate</br> a unique, secure password.</p>
                                </div>
                            </div> <!-- services content -->
                        </div>
                        <div class="col-md-6">
                            <div class="services-content mt-40 d-sm-flex">
                                <div class="services-icon">
                                    <i class="lni-brush"></i>
                                </div>
                                <div class="services-content media-body">
                                    <h4 class="services-title">Fill forms with one click</h4>
                                    <p class="text">Your shipping details, credit cards</br> and even job aplication forms</br> can be filled by a single click.</p>
                                </div>
                            </div> <!-- services content -->
                        </div>
                        <div class="col-md-6">
                            <div class="services-content mt-40 d-sm-flex">
                                <div class="services-icon">
                                    <i class="lni-bulb"></i>
                                </div>
                                <div class="services-content media-body">
                                    <h4 class="services-title">Dark web monitoring</h4>
                                    <p class="text">We are scaning for data breaches</br> and will notify you if one of your</br>accounts has been compromised.</p>
                                </div>
                            </div> <!-- services content -->
                        </div>
                    </div> <!-- row -->
                </div> <!-- row -->
            </div> <!-- row -->
        </div> <!-- conteiner -->
        <div class="services-image d-lg-flex align-items-center">
            <div class="image">
                <img src="<?php echo e(asset('images/services.jpg')); ?>" alt="Services">
            </div>
        </div> <!-- services image -->
    </section>

    <!--====== SERVICES PART ENDS ======-->

    <!--====== PRICING PART START ======-->

    <section id="pricing" class="pricing-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="section-title text-center pb-10">
                        <h4 class="title">Our Plans</h4>
                        <p class="text">Instantly increase your online security with LastPass. Choose the plant that works the best for your needs!</p>
                    </div> <!-- section title -->
                </div>
            </div> <!-- row -->
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-7 col-sm-9">
                    <div class="single-pricing mt-40">
                        <div class="pricing-header text-center">
                            <h5 class="sub-title">Free</h5>
                            <span class="price">FREE</span>
                            
                        </div>
                        <div class="pricing-list">
                            <ul>
                                <li><i class="lni-check-mark-circle"></i> Access on all devices</li>
                                <li><i class="lni-check-mark-circle"></i> One-to-one sharing</li>
                                <li><i class="lni-check-mark-circle"></i> Save & fill passwords</li>
                                <li><i class="lni-check-mark-circle"></i> Password generator</li>
                                <li><i class="lni-check-mark-circle"></i> Secure notes</li>
                                <li><i class="lni-check-mark-circle"></i> Multi-factor authentication</li>
                            </ul>
                        </div>
                        <div class="pricing-btn text-center">
                            <a class="main-btn" href="#">GET LastPass FREE</a>
                        </div>
                        <div class="buttom-shape">
                            <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 350 112.35"><defs><style>.color-1{fill:#D32D27;isolation:isolate;}.cls-1{opacity:0.1;}.cls-2{opacity:0.2;}.cls-3{opacity:0.4;}.cls-4{opacity:0.6;}</style></defs><title>bottom-part1</title><g id="bottom-part"><g id="Group_747" data-name="Group 747"><path id="Path_294" data-name="Path 294" class="cls-1 color-1" d="M0,24.21c120-55.74,214.32,2.57,267,0S349.18,7.4,349.18,7.4V82.35H0Z" transform="translate(0 0)"/><path id="Path_297" data-name="Path 297" class="cls-2 color-1" d="M350,34.21c-120-55.74-214.32,2.57-267,0S.82,17.4.82,17.4V92.35H350Z" transform="translate(0 0)"/><path id="Path_296" data-name="Path 296" class="cls-3 color-1" d="M0,44.21c120-55.74,214.32,2.57,267,0S349.18,27.4,349.18,27.4v74.95H0Z" transform="translate(0 0)"/><path id="Path_295" data-name="Path 295" class="cls-4 color-1" d="M349.17,54.21c-120-55.74-214.32,2.57-267,0S0,37.4,0,37.4v74.95H349.17Z" transform="translate(0 0)"/></g></g></svg>
                        </div>
                    </div> <!-- single pricing -->
                </div>
                
                <div class="col-lg-4 col-md-7 col-sm-9">
                    <div class="single-pricing pro mt-40">
                        <div class="pricing-baloon">
                            <img src="images/paper-plane.png" alt="baloon">
                        </div>
                        <div class="pricing-header">
                            <h5 class="sub-title">Premium</h5>
                            <span class="price">$ 2.90</span>
                            <p class="year">per month</p>
                        </div>
                        <div class="pricing-list">
                            <ul>
                            	<li><p class="year">Premium includes everything in Free, plus:</p></li>
                                <li><i class="lni-check-mark-circle"></i> One-to-many sharing</li>
                                <li><i class="lni-check-mark-circle"></i> Emergency access</li>
                                <li><i class="lni-check-mark-circle"></i> Advanced multi-factor options</li>
                                <li><i class="lni-check-mark-circle"></i> Priority tech support</li>
                                <li><i class="lni-check-mark-circle"></i> LastPass for applications</li>
                                <li><i class="lni-check-mark-circle"></i> 1GB encrypted file storage</li>
                                <li><i class="lni-check-mark-circle"></i> Dark web monitoring</li>
                                <li><i class="lni-check-mark-circle"></i> Security Dashboard</li>
                            </ul>
                        </div>
                        <div class="pricing-btn text-center">
                            <a class="main-btn" href="#">GET STARTED</a>
                        </div>
                        <div class="buttom-shape">
                            <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 350 112.35"><defs><style>.color-2{fill:#0067f4;isolation:isolate;}.cls-1{opacity:0.1;}.cls-2{opacity:0.2;}.cls-3{opacity:0.4;}.cls-4{opacity:0.6;}</style></defs><title>bottom-part1</title><g id="bottom-part"><g id="Group_747" data-name="Group 747"><path id="Path_294" data-name="Path 294" class="cls-1 color-2" d="M0,24.21c120-55.74,214.32,2.57,267,0S349.18,7.4,349.18,7.4V82.35H0Z" transform="translate(0 0)"/><path id="Path_297" data-name="Path 297" class="cls-2 color-2" d="M350,34.21c-120-55.74-214.32,2.57-267,0S.82,17.4.82,17.4V92.35H350Z" transform="translate(0 0)"/><path id="Path_296" data-name="Path 296" class="cls-3 color-2" d="M0,44.21c120-55.74,214.32,2.57,267,0S349.18,27.4,349.18,27.4v74.95H0Z" transform="translate(0 0)"/><path id="Path_295" data-name="Path 295" class="cls-4 color-2" d="M349.17,54.21c-120-55.74-214.32,2.57-267,0S0,37.4,0,37.4v74.95H349.17Z" transform="translate(0 0)"/></g></g></svg>
                        </div>
                    </div> <!-- single pricing -->
                </div>
                
                <div class="col-lg-4 col-md-7 col-sm-9">
                    <div class="single-pricing enterprise mt-40">
                        <div class="pricing-flower">
                            <img src="images/flower.svg" alt="flower">
                        </div>
                        <div class="pricing-header text-right">
                            <h5 class="sub-title">Families</h5>
                            <span class="price">$ 3.90</span>
                            <p class="year">per month</p>
                        </div>
                        <div class="pricing-list">
                            <ul>
                            	<li><p class="year">Families includes everything in Premium, plus: </p></li>
                                <li><i class="lni-check-mark-circle"></i> 6 Premium licenses</li>
                                <li><i class="lni-check-mark-circle"></i> Group and share items in folders</li>
                                <li><i class="lni-check-mark-circle"></i> Family manager dashboard</li>
                            </ul>
                        </div>
                        <div class="pricing-btn text-center">
                            <a class="main-btn" href="#">GET STARTED</a>
                        </div>
                        <div class="buttom-shape">
                            <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 350 112.35"><defs><style>.color-3{fill:#4da422;isolation:isolate;}.cls-1{opacity:0.1;}.cls-2{opacity:0.2;}.cls-3{opacity:0.4;}.cls-4{opacity:0.6;}</style></defs><title>bottom-part1</title><g id="bottom-part"><g id="Group_747" data-name="Group 747"><path id="Path_294" data-name="Path 294" class="cls-1 color-3" d="M0,24.21c120-55.74,214.32,2.57,267,0S349.18,7.4,349.18,7.4V82.35H0Z" transform="translate(0 0)"/><path id="Path_297" data-name="Path 297" class="cls-2 color-3" d="M350,34.21c-120-55.74-214.32,2.57-267,0S.82,17.4.82,17.4V92.35H350Z" transform="translate(0 0)"/><path id="Path_296" data-name="Path 296" class="cls-3 color-3" d="M0,44.21c120-55.74,214.32,2.57,267,0S349.18,27.4,349.18,27.4v74.95H0Z" transform="translate(0 0)"/><path id="Path_295" data-name="Path 295" class="cls-4 color-3" d="M349.17,54.21c-120-55.74-214.32,2.57-267,0S0,37.4,0,37.4v74.95H349.17Z" transform="translate(0 0)"/></g></g></svg>
                        </div>
                    </div> <!-- single pricing -->
                </div>
            </div> <!-- row -->
        </div> <!-- conteiner -->
    </section>

    <!--====== PRICING PART ENDS ======-->
    
     <!--====== CALL TO ACTION PART START ======-->

    <section id="call-to-action" class="call-to-action">
        <div class="call-action-image">
            <img src="images/Newsletter-image.jpg" alt="An illustration of a man with a megaphone sending emails">
        </div>
        
        <div class="container-fluid">
            <div class="row justify-content-end">
                <div class="col-lg-6">
                    <div class="call-action-content text-center">
                        <h2 class="call-title">Curious to Learn More?</h2>
                        <p class="text">Stay up to date with latest news in cyber security and data breaches. Sign up for our newsletter today!</p>
                        <div class="call-newsletter">
                            <i class="lni-envelope"></i>
                            <input type="text" placeholder="john@email.com">
                            <button type="submit">SUBSCRIBE</button>
                        </div>
                    </div> <!-- slider-content -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>

    <!--====== CALL TO ACTION PART ENDS ======-->
    
    <!--====== CONTACT PART START ======-->
                        <?php if(Auth::guest()): ?>

    <section id="contact" class="contact-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="section-title text-center pb-10">
                        <h4 class="title">Make Appointment</h4>
                        <p class="text">If you have any questions regarding our services, plans or need help with your existing account, don't hesitate to contact our support team.</p>
                    </div> <!-- section title -->
                </div>
            </div> <!-- row -->
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <?php echo $__env->make('layout/error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="container">
                        <a href="<?php echo e(URL::previous()); ?>" class="btn btn-dark">Go Back</a><br><br>
                        <h5 class="alert alert-warning" role="alert">Ukoliko imate hitan slucaj - pozovite nas! 555-555-555</h5>
                        <h1>Zakazite termin</h1>
                    <div class="contact-form">
                        <?php echo $__env->make('layout.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                         <?php echo Form::open(['action' => 'App\Http\Controllers\ScheduleController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data',  'class' => 'submit-form']); ?>    
                                    
                                        <div class="row">
                                                <div class="col-md-6">
                                                    <div class="single-form form-group">
                                                        <?php echo Form::text('subject','', ["placeholder" => "Naslov"]); ?>

                                                    </div>
                                                </div>              
                                                  
                                                    <div class="col-md-3">
                                                        <div class="single-form form-group">
                                                           <input type="datetime-local"    name="dateStart" id="date-create"> 
                                                           
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="single-form form-group">
                                                           <input type="datetime-local"   name="dateEnd" class="date-create">
                                                           
                                                        </div>
                                                    </div>
                                                 
                                                    <div class="col-md-12">
                                                        <div class="single-form form-group">
                                                            <?php echo Form::textarea('message','',['placeholder' => 'Poruka']); ?>

                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 float-right"><?php echo Form::file('cover_image'); ?></div>
                                                    <div class="col-md-6">
                                                        <?php echo e(Form::submit('Submit',["class" => "col-md-12 btn btn-danger", "id" => "submit"])); ?>

                                                    <?php echo Form::close(); ?>

                                                </div> <!-- row -->
                                
                                        </div> <!-- row -->
                                    </div>
                                    
                                </div>
                                <script>
                                    config ={
                                        enableTime: true,
                                        dateFormat: "d.m.Y H:i",
                                        altInput: true,
                                        time_24hr: true,
                                        minDate:"today",
                                        maxDate: new Date().fp_incr(120),
                                        minTime: "08:00",
                                        maxTime: "16:30",
                                    }
                                    flatpickr('input[type=datetime-local]', config);
                                </script>
            <?php endif; ?>    
        </div> <!-- row -->
        </div> <!-- conteiner -->
    </section>

    <!--====== CONTACT PART ENDS ======-->

    

    <!--====== BACK TO TOP PART START ======-->

    <a class="back-to-top" href="#"><i class="lni-chevron-up"></i></a>

    <!--====== BACK TO TOP PART ENDS ======-->









    <!--====== jquery js ======-->
    <script src="<?php echo e(asset('js/vendor/modernizr-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/vendor/jquery-1.12.4.min.js')); ?>"></script>

    <!--====== Bootstrap js ======-->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>

    <!--====== Scrolling Nav js ======-->
    <script src="<?php echo e(asset('js/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scrolling-nav.js')); ?>"></script>

    <!--====== Magnific Popup js ======-->
    <script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>

    <!--====== Main js ======-->
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>

</body>

</html>
<?php /**PATH /home/cvetko/dentists/resources/views/layout/index.blade.php ENDPATH**/ ?>