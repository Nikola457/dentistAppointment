<?php echo $__env->make('layout/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">

        <?php if(count($users) > 0 ): ?>
        <h1>Pacijenti</h1>
        <?php echo Form::open(['action' => 'App\Http\Controllers\HomeController@showAllPatients', 'method' => 'GET', 'enctype' => 'multipart/form-data',  'class' => 'search-form']); ?>    
        <?php echo Form::submit("Search",['class' => 'btn btn-primary float-right', 'id' => 'search-input-patients']); ?>

        <?php echo Form::text('searchInput','', ["placeholder" => "Pretrazi", 'class' => 'float-right' , 'id' => 'searchInput']); ?>


            <?php echo Form::close(); ?>

            <table class="table-responsive patients-table">
                <tr><th>Ime i prezime pacijenta</th>
                    <th>Email adresa</th>
                    <th>Broj telefona</th>
                    <th>JMBG</th>
                    <th>Istorija pacijenta</th>
                </tr>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>0650460325</td>
                    <td>31109987736373</td>
                    <td><a class="btn btn-info" href="dashboard/<?php echo e($user->id); ?>">Istorija pacijenta</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php else: ?> 
            <h1>Trenutno nemate nijednog pacijenta</h1>
            <?php echo Form::open(['action' => 'App\Http\Controllers\HomeController@showAllPatients', 'method' => 'GET', 'enctype' => 'multipart/form-data',  'class' => 'search-form']); ?>    
        <?php echo Form::submit("Search",['class' => '', 'id' => 'search-input-patients', 'id' => 'search-input-patients']); ?>

        <?php echo Form::text('searchInput','', ["placeholder" => "Pretrazi", 'class' => 'float-right']); ?>

            <?php echo Form::close(); ?>

            <?php endif; ?>
            <div class="pagination justify-content-center" style="margin-top:30px; font-size:22px;"><?php echo e($users->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cvetko/dentists/resources/views/patients.blade.php ENDPATH**/ ?>