<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="contact-form">
        <div class="container">
            <div class="content">
                <a href="<?php echo e(URL::previous()); ?>" class="btn btn-dark">Go Back</a><br><br>
            <h1 class="text-uppercase"><?php echo e($schedule->subject); ?></h1>
            <small>Datum zakazivanja: <?php echo e($schedule->created_at); ?></small>
            <div class="card">
                <div class="card-body">
                <div class="container-show">
                <?php if($schedule->cover_image != ""): ?>
                <img class="rounded float-left" id="show-img" src="/storage/cover_images/<?php echo e($schedule->cover_image); ?>" >
                <?php endif; ?>
                <div class="show-schedule-text"><p><?php echo e($schedule->message); ?><p>

                    <small>Zakazan termin: <b> <?php echo e($schedule->scheduleDate); ?> - <?php echo e($schedule->scheduleDateEnd); ?></b></small>
                </div>
            </div>
                <?php if(Auth::user()->name === 'admin'): ?>
                <?php echo Form::open(['action' => ['App\Http\Controllers\ScheduleController@destroy', $schedule->id], 'method' => 'POST', 'enctype' => 'multipart/form-data',  'class' => 'submit-form']); ?>    
                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                        <?php echo e(Form::submit('Obrisi',["class" => "col-md-2 float-right btn btn-danger", "id" => "submit"])); ?>

                        <?php echo Form::close(); ?>

                <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
             </div>
                    <script>
                </script><?php /**PATH /home/cvetko/dentists/resources/views/schedule/show.blade.php ENDPATH**/ ?>