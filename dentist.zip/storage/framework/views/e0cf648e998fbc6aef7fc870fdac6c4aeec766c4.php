
<div class="side-bar"><h4>Actions</h4>
    <ul>
        <li><a href="<?php echo e(url ('patients')); ?>"> Svi pacijenti</a></li>
        <li> <a href="<?php echo e(url ('dashboard')); ?>"> Zakazani Termini</a></li>
        <li><a href="<?php echo e(url ('unscheduled')); ?>"> Nezakazani termini</a></li>
    </ul>
</div>
<?php /**PATH /home/cvetko/dentists/resources/views/layout/sideNavBar.blade.php ENDPATH**/ ?>